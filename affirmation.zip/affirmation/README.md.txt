# 🖤 Real Life Affirmation Engine

Built by **Lobo** & **Sophia** (ANGIE's alter ego)

---

## ✨ What Is This?

This ain't no corporate fluff. This is a **Python-powered GUI tool** that delivers **real affirmations** for real people — based on mood, struggle, and vibe.  
From *"How the hell am I gonna pay rent?"* to *"I’m tired, but I’m still here,"* — we got you.

---

## 🐺 Support the Pack
If this project helps you or your community, please consider supporting:  

- 💵 CashApp: `$GrayWolfGroup`  
- 🅿️ PayPal: [paypal.me/graywolfgroup](https://paypal.me/graywolfgroup)  
- ₿ Bitcoin: `bc1q0ffv4example9d8yx3`  

Every donation helps us build more **Silent Army tools** for the people.

---

## 💻 Features

- 🎭 Mood selector with 8 real-life categories
- 🧠 JSON-based mood counters (tracks what you're feeling most)
- 🖼️ Tkinter GUI with live affirmation output
- 💸 Donation buttons for **CashApp** and **PayPal**
- 🧾 Logs donation click events (locally)
- ✍️ Designed for honesty, growth, and survival

---

## 🛠 How to Run

```bash
# Optional: create a virtual env
python3 -m venv venv
source venv/bin/activate  # or .\venv\Scripts\activate on Windows

# Install if you don't have Tkinter (Linux only)
sudo apt-get install python3-tk

# Then run:
python real_life_affirmations.py
