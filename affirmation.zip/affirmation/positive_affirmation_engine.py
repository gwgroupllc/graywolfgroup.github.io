import tkinter as tk
from tkinter import ttk, messagebox
import random
import datetime
import json
import webbrowser
import os
import argparse

# ────────────────────────────────────────────────
# 🐺 Gray Wolf Affirmation Engine
# Authors: Lobo & Sophia
#
# Modes:
#   Default (Light) → clean + public affirmations
#   --dark          → Yami / Dark Wolf Mode (raw, heavy)
#   --gogo          → Gogo Mode (chaotic, petty, wild)
#
# Donationware • Free to remix • Support encouraged
# CashApp: $4EVERMONEYBAGZ | PayPal: @Graywolfgroup
# ────────────────────────────────────────────────

# Donation URLs
CASHAPP_URL = "https://cash.app/4EVERMONEYBAGZ"
PAYPAL_URL = "https://paypal.me/Graywolfgroup"

# Mode settings
MODE_CONFIG = {
    "light": {
        "file": "affirmations_light.json",
        "mood_log": "mood_counter_light.json",
        "title": "✨ Real Life Affirmations (Light Mode)",
        "bg": "#1c1c1c",
        "fg": "#f2f2f2"
    },
    "dark": {
        "file": "yami_affirmations.json",
        "mood_log": "mood_counter_dark.json",
        "title": "⚫ Real Life Affirmations (Dark Wolf Mode)",
        "bg": "#0a0a0a",
        "fg": "#f94144"
    },
    "gogo": {
        "file": "gogo_affirmations.json",
        "mood_log": "mood_counter_gogo.json",
        "title": "🔥 Real Life Affirmations (Gogo Mode)",
        "bg": "#330000",
        "fg": "#ffb703"
    }
}

DONATION_LOG = "donations.log"

# Default fallback affirmations
DEFAULT_AFFIRMATIONS = {
    "Focused": ["Lock in. This moment is yours.", "Block the noise. Build your empire."],
    "Tired": ["Rest ain’t quitting. Wolves reload.", "Crash, but rise sharper."],
    "Happy": ["Protect your joy — it’s currency.", "Laugh hard, heal loud."],
    "Stressed": ["Control the controllable. Release the rest.", "You won’t break, even if bent."],
    "Lost": ["Even the wolf howls to find the pack.", "You’re rerouting, not failing."],
    "Petty": ["Flex in silence. Let ‘em wonder.", "Royalty don’t wrestle with peasants."],
    "Fiending": ["Craving ain’t calling. Choose you.", "Your future’s worth more than that hit."],
    "Woke": ["See the game. Move like you coded it.", "Truth hurts — but lies kill."]
}

# ────────────────────────────────────────────────
# Utilities
# ────────────────────────────────────────────────

def load_json(filepath, default):
    if not os.path.exists(filepath):
        with open(filepath, "w") as f:
            json.dump(default, f, indent=2)
    with open(filepath, "r") as f:
        return json.load(f)

def save_json(filepath, data):
    with open(filepath, "w") as f:
        json.dump(data, f, indent=2)

def log_donation(service):
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(DONATION_LOG, "a") as f:
        f.write(f"{timestamp} - Clicked {service}\n")

# ────────────────────────────────────────────────
# Affirmation Engine Class
# ────────────────────────────────────────────────

class AffirmationApp:
    def __init__(self, root, mode="light"):
        self.mode = mode
        cfg = MODE_CONFIG[mode]

        self.root = root
        self.root.title(cfg["title"])
        self.root.geometry("480x460")
        self.root.configure(bg=cfg["bg"])

        # Load affirmations + mood counters
        self.affirmations = load_json(cfg["file"], DEFAULT_AFFIRMATIONS)
        self.mood_counts = load_json(cfg["mood_log"], {m: 0 for m in self.affirmations})

        self.bg = cfg["bg"]
        self.fg = cfg["fg"]

        self.setup_gui()

    def setup_gui(self):
        title = tk.Label(self.root, text="Gray Wolf Affirmation Engine", bg=self.bg, fg=self.fg, font=("Helvetica", 16, "bold"))
        title.pack(pady=10)

        self.mood_var = tk.StringVar(value=list(self.affirmations.keys())[0])
        mood_label = tk.Label(self.root, text="How you feelin’ today?", bg=self.bg, fg=self.fg)
        mood_label.pack(pady=(10, 2))

        mood_menu = ttk.Combobox(self.root, textvariable=self.mood_var, values=list(self.affirmations.keys()), state="readonly")
        mood_menu.pack(pady=5)

        get_btn = tk.Button(self.root, text="Get My Affirmation", command=self.show_affirmation, bg="#f2b600", fg="black", font=("Arial", 12, "bold"))
        get_btn.pack(pady=10)

        self.output_label = tk.Label(self.root, text="", wraplength=420, justify="center", bg=self.bg, fg=self.fg, font=("Arial", 12))
        self.output_label.pack(pady=20)

        # Donation buttons
        support_label = tk.Label(self.root, text="Support the Wolf Pack", bg=self.bg, fg=self.fg, font=("Arial", 10, "italic"))
        support_label.pack(pady=(10, 0))

        donate_frame = tk.Frame(self.root, bg=self.bg)
        donate_frame.pack(pady=5)

        tk.Button(donate_frame, text="💸 CashApp", command=lambda: self.open_donation("CashApp", CASHAPP_URL)).pack(side="left", padx=10)
        tk.Button(donate_frame, text="💸 PayPal", command=lambda: self.open_donation("PayPal", PAYPAL_URL)).pack(side="left", padx=10)

        barter_label = tk.Label(self.root, text="Can’t donate? Barter. Share. Energy always flows back. 🖤", bg=self.bg, fg=self.fg, font=("Arial", 8), wraplength=440)
        barter_label.pack(pady=(20, 0))

    def show_affirmation(self):
        mood = self.mood_var.get()
        affirm_list = self.affirmations.get(mood, ["You’re still standing. That counts."])
        chosen = random.choice(affirm_list)
        self.output_label.config(text=f"✨ {chosen}")
        self.mood_counts[mood] += 1
        cfg = MODE_CONFIG[self.mode]
        save_json(cfg["mood_log"], self.mood_counts)

    def open_donation(self, service, url):
        log_donation(service)
        webbrowser.open(url)

# ────────────────────────────────────────────────
# Main
# ────────────────────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--dark", action="store_true", help="Run in Dark Wolf Mode")
    parser.add_argument("--gogo", action="store_true", help="Run in Gogo Mode")
    args = parser.parse_args()

    mode = "light"
    if args.dark:
        mode = "dark"
    elif args.gogo:
        mode = "gogo"

    root = tk.Tk()
    app = AffirmationApp(root, mode=mode)
    root.mainloop()
