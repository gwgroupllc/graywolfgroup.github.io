# 🛡️ Guardian Lite  
*A Silent Army Demo Tool by Gray Wolf Group LLC*

---

## 🐺 Support the Pack
If this project helps you or your community, please consider supporting:  

- 💵 CashApp: `$GrayWolfGroup`  
- 🅿️ PayPal: [paypal.me/graywolfgroup](https://paypal.me/graywolfgroup)  
- ₿ Bitcoin: `bc1q0ffv4example9d8yx3`  

Every donation helps us build more **Silent Army tools** for the people.

---

## ⚡ What is Guardian Lite?  
Guardian Lite is a **demo cyber-defense tool** created by **Gray Wolf Group LLC**.  
It’s built to **show everyday users how digital guardianship works** — without overwhelming configs.  

Features:  
- 🔍 Scans directories for suspicious file types  
- 🖥️ Monitors high-resource processes  
- 🌐 Flags network connections to blacklisted domains  
- 📜 Logs all events in `guardian_log.json`  

Guardian Lite is the **starter shield** — a free demo pointing toward the **Guardian Pro Pack**, which delivers the full arsenal.  

---

## 💻 How to Run  

Clone this repo, then run:  

```bash
python3 guardian_lite.py
