import os
import psutil
import socket
import json
import datetime

# ------------------------------
# Guardian Lite Config
# ------------------------------
CONFIG = {
    "suspicious_extensions": [".exe", ".bat", ".scr", ".pif", ".vbs", ".js"],
    "blacklist_domains": ["malware.test", "phishingsite.com", "badwolf.net"],
    "log_file": "guardian_log.json"
}

# ------------------------------
# Helper: log events
# ------------------------------
def log_event(event_type, details):
    entry = {
        "timestamp": datetime.datetime.now().isoformat(),
        "event": event_type,
        "details": details
    }

    if not os.path.exists(CONFIG["log_file"]):
        with open(CONFIG["log_file"], "w") as f:
            json.dump([], f)

    with open(CONFIG["log_file"], "r+") as f:
        data = json.load(f)
        data.append(entry)
        f.seek(0)
        json.dump(data, f, indent=2)

    print(f"[LOGGED] {event_type}: {details}")

# ------------------------------
# Scan for suspicious files
# ------------------------------
def scan_directory(path="."):
    print(f"\n🔍 Scanning directory: {os.path.abspath(path)}")
    for root, _, files in os.walk(path):
        for file in files:
            if any(file.endswith(ext) for ext in CONFIG["suspicious_extensions"]):
                details = f"Suspicious file: {os.path.join(root, file)}"
                log_event("File Scan", details)

# ------------------------------
# Monitor processes
# ------------------------------
def monitor_processes():
    print("\n🖥️ Checking running processes...")
    for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent']):
        try:
            if proc.info['cpu_percent'] > 50 or proc.info['memory_percent'] > 50:
                details = f"High resource usage: {proc.info}"
                log_event("Process Monitor", details)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue

# ------------------------------
# Network check
# ------------------------------
def network_monitor():
    print("\n🌐 Checking network connections...")
    for conn in psutil.net_connections(kind="inet"):
        if conn.raddr:
            try:
                domain = socket.gethostbyaddr(conn.raddr.ip)[0]
                if any(bad in domain for bad in CONFIG["blacklist_domains"]):
                    details = f"Blacklisted connection: {domain}"
                    log_event("Network Monitor", details)
            except Exception:
                continue

# ------------------------------
# Guardian Lite Main
# ------------------------------
def run_guardian():
    print("\n🛡️ Guardian Lite — GWG Silent Army Demo\n")
    scan_directory(".")
    monitor_processes()
    network_monitor()
    print("\n✅ Scan complete. Check guardian_log.json for full report.\n")

if __name__ == "__main__":
    run_guardian()
