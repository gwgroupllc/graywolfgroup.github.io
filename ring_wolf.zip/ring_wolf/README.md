# 🥊 Ring Wolf — Silent Army Boxing Demo

---

## 🐺 Support the Pack
If this project knocks for you, support the Silent Army:

- 💵 CashApp: `$GrayWolfGroup`
- 🅿️ PayPal: [paypal.me/graywolfgroup](https://paypal.me/graywolfgroup)
- ₿ Bitcoin: `bc1q0ffv4example9d8yx3`

---

## 🧠 What is this?
Ring Wolf is a **demo boxing game** built in Python.  
It’s turn-based, like the classics (*Ring King*, *Punch-Out*), but designed to **grow into a bigger model**.

This repo shows:
- Turn-based boxing with punches + block
- Health + stamina system
- Rounds & scoring
- CPU AI with random moves
- Expandable structure (stats, graphics, combos)

---

## 💻 Run It
```bash
python3 ring_wolf.py
