import random
import time

class Fighter:
    def __init__(self, name, health=100, stamina=100, power=1.0, defense=1.0):
        self.name = name
        self.health = health
        self.stamina = stamina
        self.power = power
        self.defense = defense
    
    def is_alive(self):
        return self.health > 0

    def adjust_stamina(self, cost):
        self.stamina = max(0, self.stamina - cost)

    def restore_stamina(self, amount):
        self.stamina = min(100, self.stamina + amount)

moves = {
    "jab": {"damage": 10, "stamina": 5},
    "hook": {"damage": 15, "stamina": 10},
    "uppercut": {"damage": 20, "stamina": 15},
    "block": {"damage": 0, "stamina": 3}
}

def attack(attacker, defender, move):
    if attacker.stamina < moves[move]["stamina"]:
        print(f"{attacker.name} is too tired to throw a {move}!")
        return
    
    attacker.adjust_stamina(moves[move]["stamina"])
    dmg = int(moves[move]["damage"] * attacker.power)

    if move == "block":
        print(f"{attacker.name} blocks!")
        attacker.restore_stamina(5)
        return

    # Defense calculation
    if random.random() < 0.25:
        dmg = int(dmg * defender.defense * 0.5)
        print(f"{defender.name} partially blocks the {move}!")
    else:
        dmg = int(dmg * defender.defense)

    defender.health = max(0, defender.health - dmg)
    print(f"{attacker.name} lands a {move}! (-{dmg})")

def fight_round(player, cpu):
    while player.is_alive() and cpu.is_alive():
        print(f"\n🩸 {player.name} {player.health} HP | {cpu.name} {cpu.health} HP")
        move = input("Choose [jab, hook, uppercut, block]: ").lower()
        if move in moves:
            attack(player, cpu, move)
        else:
            print("Invalid move. You hesitate.")

        if not cpu.is_alive(): break
        time.sleep(1)
        cpu_move = random.choice(list(moves.keys()))
        attack(cpu, player, cpu_move)

def game():
    print("🥊 Welcome to RING WOLF — Silent Army Demo\n")
    player = Fighter("Player", power=1.1, defense=0.9)
    cpu = Fighter("CPU", power=1.0, defense=1.0)

    rounds = 3
    for r in range(1, rounds+1):
        print(f"\n=== ROUND {r} ===")
        fight_round(player, cpu)
        if not player.is_alive() or not cpu.is_alive():
            break
        player.restore_stamina(20)
        cpu.restore_stamina(20)

    print("\n🏁 Fight Over!")
    if player.health > cpu.health:
        print("🏆 Player wins on points!")
    elif cpu.health > player.health:
        print("💀 CPU wins on points!")
    else:
        print("🤝 It's a draw!")

if __name__ == "__main__":
    game()
