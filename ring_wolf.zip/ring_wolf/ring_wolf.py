import random
import time

# Basic stats
player = {"name": "Player", "health": 100}
cpu = {"name": "CPU", "health": 100}

moves = {
    "jab": 10,
    "hook": 15,
    "uppercut": 20,
    "block": 0
}

def print_health():
    print(f"\n{player['name']} 🩸 {player['health']} | {cpu['name']} 🩸 {cpu['health']}")

def attack(attacker, defender, move):
    dmg = moves[move]
    if move == "block":
        print(f"{attacker['name']} blocks!")
        return
    
    # CPU has 25% chance to block
    if defender["name"] == "CPU" and random.random() < 0.25:
        print(f"{defender['name']} blocks the {move}!")
        dmg = int(dmg/2)
    
    defender["health"] -= dmg
    print(f"{attacker['name']} lands a {move}! (-{dmg})")

def cpu_turn():
    move = random.choice(list(moves.keys()))
    attack(cpu, player, move)

def player_turn():
    print("\nChoose your move: [jab, hook, uppercut, block]")
    move = input("> ").lower()
    if move not in moves:
        print("Invalid move, you lose your turn!")
        return
    attack(player, cpu, move)

def game():
    print("🥊 Welcome to RING WOLF 🐺\n")
    while player["health"] > 0 and cpu["health"] > 0:
        print_health()
        player_turn()
        if cpu["health"] <= 0:
            break
        time.sleep(1)
        cpu_turn()
    
    print_health()
    if player["health"] > 0:
        print("\n🏆 You win! The wolf stays on top!")
    else:
        print("\n💀 You got knocked out...")

if __name__ == "__main__":
    game()
