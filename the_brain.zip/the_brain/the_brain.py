import json
import random
import datetime
import os

# Load topics from JSON
with open("topics.json", "r") as f:
    topics = json.load(f)

# Ensure log file exists
if not os.path.exists("lesson_log.json"):
    with open("lesson_log.json", "w") as log_file:
        json.dump([], log_file)

def log_lesson(subject):
    timestamp = datetime.datetime.now().isoformat()
    with open("lesson_log.json", "r+") as f:
        log = json.load(f)
        log.append({"subject": subject, "timestamp": timestamp})
        f.seek(0)
        json.dump(log, f, indent=2)

def teach(subject):
    if subject not in topics:
        print("❌ Sorry, that subject is not available... yet.")
        return

    print(f"\n📘 Subject: {subject}")
    print("-" * 40)

    for line in topics[subject]["lesson"]:
        print(f"🧠  {line}")

    print("\n✅ Lesson complete.")

    if "question" in topics[subject]:
        answer = input(f"\n❓ {topics[subject]['question']}\nYour answer: ")
        print("🗣️  Great try. The point is to keep thinking.")

    # Log it
    log_lesson(subject)

    # Optional crawler hook
    more = input("\n🔍 Want me to look up extra study help online? (yes/no): ").strip().lower()
    if more == "yes":
        import web_crawler
        keywords = topics[subject].get("keywords", [])
        if keywords:
            web_crawler.search(keywords)
        else:
            print("⚠️  No keywords found for web search.")

if __name__ == "__main__":
    print("🎓 WELCOME TO: THE BRAIN")
    print("Knowledge that talks back.\n")
    print("Available Subjects:")
    for sub in topics:
        print(f" • {sub}")
    choice = input("\nWhat do you want to learn today? ").strip()
    teach(choice)
