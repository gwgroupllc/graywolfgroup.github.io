import requests
from bs4 import BeautifulSoup
import time

# 🔗 Extra trades & creative career keywords (always included in searches)
BASE_EXPANDED_KEYWORDS = [
    # Trades
    "barber school", "nail tech classes", "makeup certification",
    "hairstyling academy", "cosmetology training",
    "auto repair trade school", "hvac certification", "plumbing apprenticeship",
    "electrician trade school", "construction apprentice program", "carpentry basics",
    "cdl truck driving school",
    # Creative paths
    "screenwriting class", "novelist training", "self publishing beginner",
    "public speaking bootcamp", "toastmasters class",
    "fashion design trade school", "beginner sewing class",
    "dog grooming certification", "pet stylist training",
    "content creation bootcamp", "youtube creator starter kit",
    "music production beginner", "free daw software", "learn beat making",
    "film editing training", "adobe premiere tutorial",
    "life coach certification", "herbalist training", "holistic healer certification",
    # Digital + tech
    "freecodecamp web development", "coding bootcamp beginner",
    "cybersecurity certificate program"
]

def search(keywords):
    print("\n🛰️  Activating Web Crawler...")
    print("Searching trusted sources for study help, trades, and creator skills.")

    # Merge user/topic keywords with hard-coded expansion
    expanded_keywords = []
    for word in keywords:
        expanded_keywords.extend([
            f"{word} trade school",
            f"{word} certificate program",
            f"{word} how to start",
            f"{word} online bootcamp",
            f"{word} tutorial site:youtube.com",
            f"{word} training site:trade-schools.net",
            f"{word} program site:indeed.com"
        ])
    expanded_keywords.extend(BASE_EXPANDED_KEYWORDS)

    # Crawl through all queries
    for query in expanded_keywords:
        print(f"\n🔍 Searching: {query}")
        try:
            url = f"https://duckduckgo.com/html/?q={query}"
            headers = {'User-Agent': 'Mozilla/5.0'}
            response = requests.get(url, headers=headers)
            soup = BeautifulSoup(response.text, "html.parser")

            results = soup.find_all("a", class_="result__a", limit=3)
            if not results:
                print("⚠️  No results found.")
                continue

            for link in results:
                title = link.text.strip()
                href = link.get("href")
                print(f"🔗 {title}\n   → {href}")

            time.sleep(1)  # Be polite to servers

        except Exception as e:
            print(f"⚠️  Error while crawling: {e}")
            continue

    print("\n✅ Web crawl complete. Save what matters, LOBO.")
