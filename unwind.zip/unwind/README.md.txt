# 🎓 Overload → Unwind  
*A Silent Army Curriculum Demo by Gray Wolf Group LLC*

---

## 🐺 Support the Pack
If this project helps you or your community, please consider supporting:  

- 💵 CashApp: `$GrayWolfGroup`  
- 🅿️ PayPal: [paypal.me/graywolfgroup](https://paypal.me/graywolfgroup)  
- ₿ Bitcoin: `bc1q0ffv4example9d8yx3`  

Every donation helps us build more **Silent Army tools** for the people.

---

## 🧠 What is it?  
**Overload → Unwind** is a learning engine designed to give people a **second chance**:  
- 12 core subjects (from grammar to hidden history)  
- Study reflection questions  
- Extra learning resources via a built-in web crawler  
- A calming **Unwind Exercise** after every lesson to help reset the mind  

This is not a school. This is **freedom education**.

---

## 📂 How it Works
1. Pick a subject (English, Math, GED, Trades, Content Creation, History, etc.)  
2. Read through the lesson and reflect with a short question  
3. Log your progress automatically  
4. Receive a **guided relaxation exercise** to decompress  
5. Optionally trigger the **web crawler** to find YouTube tutorials, trade schools, and resources  

---

## 💻 Run It
Clone this repo, then run:

```bash
python3 overload_unwind.py
