import json
import datetime
import os
import requests
from bs4 import BeautifulSoup
import time
import random

# ------------------------------
# Load subjects + unwind steps from JSON
# ------------------------------
with open("overload_unwind.json", "r") as f:
    data = json.load(f)

topics = data["subjects"]
relaxation_exercises = data["unwind"]

# ------------------------------
# Simple crawler
# ------------------------------
def crawl(keywords):
    expanded = []
    for word in keywords:
        expanded.extend([
            f"{word} trade school", f"{word} certificate program",
            f"{word} tutorial site:youtube.com",
            f"{word} training site:trade-schools.net"
        ])

    for query in expanded:
        print(f"\n🔍 {query}")
        try:
            url = f"https://duckduckgo.com/html/?q={query}"
            headers = {'User-Agent': 'Mozilla/5.0'}
            r = requests.get(url, headers=headers)
            soup = BeautifulSoup(r.text, "html.parser")
            results = soup.find_all("a", class_="result__a", limit=2)
            for link in results:
                print(f"🔗 {link.text.strip()}\n   → {link.get('href')}")
            time.sleep(1)
        except Exception as e:
            print(f"⚠️  Error: {e}")

# ------------------------------
# Lesson logging
# ------------------------------
def log(subject):
    ts = datetime.datetime.now().isoformat()
    if not os.path.exists("lesson_log.json"):
        with open("lesson_log.json", "w") as f:
            json.dump([], f)
    with open("lesson_log.json", "r+") as f:
        log = json.load(f)
        log.append({"subject": subject, "timestamp": ts})
        f.seek(0)
        json.dump(log, f, indent=2)

# ------------------------------
# Teacher flow
# ------------------------------
def teach(subject):
    if subject not in topics:
        print("❌ Not found.")
        return
    print(f"\n📘 {subject}")
    print("-" * 40)
    for line in topics[subject]["lesson"]:
        print(f"🧠 {line}")
    print("\n✅ Lesson done.")

    ans = input(f"\n❓ {topics[subject]['question']}\nYour answer: ")
    print("🗣️ Good work. Keep building.")

    log(subject)

    # Unwind step
    print("\n--- OVERLOAD → UNWIND ---")
    print(random.choice(relaxation_exercises))

    more = input("\n🔍 Want extra resources online? (yes/no): ").strip().lower()
    if more == "yes":
        crawl(topics[subject]["keywords"])

# ------------------------------
# Main menu
# ------------------------------
if __name__ == "__main__":
    print("🎓 WELCOME TO: OVERLOAD → UNWIND — Silent Army Curriculum\n")
    print("Available Subjects:")
    for sub in topics:
        print(f" • {sub}")
    choice = input("\nWhat do you want to learn today? ").strip()
    teach(choice)
